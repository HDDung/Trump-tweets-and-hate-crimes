### Step 1: scraping data from FBI
source("../scripts/data-collection/01 - FBI-data-collection-FBI-master-data.R")


### Step 2: scraping data for controlling variables
source("../scripts/data-collection/01 - US Census Preparation.R")
